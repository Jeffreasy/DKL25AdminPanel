export interface Photo {
  id: string
  url: string
  alt: string
  visible: boolean
  order_number: number
  created_at: string
  updated_at: string
} 