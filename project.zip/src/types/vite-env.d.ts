/// <reference types="vite/client" />

declare module '@vitejs/plugin-react' {
  const plugin: () => any
  export default plugin
} 